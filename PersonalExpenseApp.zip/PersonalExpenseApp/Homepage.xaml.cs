namespace PersonalExpenseApp;

public partial class Homepage : ContentPage
{
	public Homepage()
	{
		InitializeComponent();
	}
}